<?php 
include 'config.php';
include 'header.php'; 

$hoy = date('Y-m-d');

// 1. Consultas para los indicadores (KPIs)
$total_socios = $conexion->query("SELECT COUNT(*) as total FROM socios")->fetch_assoc()['total'];
$activos = $conexion->query("SELECT COUNT(*) as total FROM socios WHERE fecha_vencimiento >= '$hoy'")->fetch_assoc()['total'];
$vencidos = $conexion->query("SELECT COUNT(*) as total FROM socios WHERE fecha_vencimiento < '$hoy'")->fetch_assoc()['total'];
$total_entrenadores = $conexion->query("SELECT COUNT(*) as total FROM entrenadores WHERE estado = 'activo'")->fetch_assoc()['total'];

// 2. Consulta para la tabla de últimas inscripciones
$recientes = $conexion->query("SELECT s.*, m.nombre as plan FROM socios s JOIN membresias m ON s.id_membresia = m.id_membresia ORDER BY s.id_socio DESC LIMIT 5");
?>

<div class="page-wrapper">
    <div class="container-xl mt-4">
        
        <div class="row align-items-center mb-4">
            <div class="col">
                <h2 class="page-title">Panel de Control (Admin)</h2>
                <div class="text-muted mt-1">Gestión del Gimnasio RR.</div>
            </div>
            <div class="col-auto">
                <div class="btn-list">
                    <a href="nuevo_entrenador.php" class="btn btn-purple text-white">
                        <i class="ti ti-plus me-2"></i> Registrar Entrenador
                    </a>
                    <a href="nuevo_socio.php" class="btn btn-primary">
                        <i class="ti ti-user-plus me-2"></i> Inscribir Socio
                    </a>
                </div>
            </div>
        </div>

        <div class="row row-cards mb-4">
            
            <div class="col-sm-6 col-lg-3">
                <a href="socios.php" class="card card-sm card-link">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col-auto"><span class="bg-blue text-white avatar"><i class="ti ti-users"></i></span></div>
                            <div class="col">
                                <div class="font-weight-medium"><?php echo $total_socios; ?> Socios</div>
                                <div class="text-muted">Ver lista completa</div>
                            </div>
                        </div>
                    </div>
                </a>
            </div>

            <div class="col-sm-6 col-lg-3">
                <a href="membresias.php" class="card card-sm card-link">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col-auto"><span class="bg-green text-white avatar"><i class="ti ti-check"></i></span></div>
                            <div class="col">
                                <div class="font-weight-medium"><?php echo $activos; ?> Activos</div>
                                <div class="text-muted">Vigentes</div>
                            </div>
                        </div>
                    </div>
                </a>
            </div>

            <div class="col-sm-6 col-lg-3">
                <a href="membresias.php" class="card card-sm card-link">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col-auto"><span class="bg-red text-white avatar"><i class="ti ti-alert-triangle"></i></span></div>
                            <div class="col">
                                <div class="font-weight-medium"><?php echo $vencidos; ?> Vencidos</div>
                                <div class="text-muted">Ver Morosos</div>
                            </div>
                        </div>
                    </div>
                </a>
            </div>

            <div class="col-sm-6 col-lg-3">
                <a href="entrenadores.php" class="card card-sm card-link">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col-auto"><span class="bg-purple text-white avatar"><i class="ti ti-barbell"></i></span></div>
                            <div class="col">
                                <div class="font-weight-medium"><?php echo $total_entrenadores; ?> Coaches</div>
                                <div class="text-muted">Ver equipo</div>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
        </div>

        <div class="row">
            <div class="col-12">
                <div class="card shadow-sm">
                    <div class="card-header border-0">
                        <h3 class="card-title">Últimas Inscripciones</h3>
                    </div>
                    <div class="table-responsive">
                        <table class="table card-table table-vcenter text-nowrap datatable">
                            <thead>
                                <tr>
                                    <th>SOCIO</th>
                                    <th>PLAN</th>
                                    <th>REGISTRADO</th>
                                    <th>VENCE EL</th>
                                    <th>ESTADO</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($r = $recientes->fetch_assoc()): 
                                    $es_vencido = (strtotime($r['fecha_vencimiento']) < strtotime($hoy));
                                ?>
                                <tr>
                                    <td><strong><?php echo $r['nombre']." ".$r['apellido']; ?></strong></td>
                                    <td><span class="badge bg-blue-lt"><?php echo $r['plan']; ?></span></td>
                                    <td><?php echo date('d/m/Y', strtotime($r['fecha_registro'])); ?></td>
                                    <td><?php echo date('d/m/Y', strtotime($r['fecha_vencimiento'])); ?></td>
                                    <td>
                                        <span class="badge bg-<?php echo $es_vencido ? 'red' : 'green'; ?>-lt">
                                            <?php echo $es_vencido ? 'VENCIDO' : 'ACTIVO'; ?>
                                        </span>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer d-flex align-items-center border-0">
                        <p class="m-0 text-muted">Mostrando los últimos 5 registros</p>
                        <a href="socios.php" class="ms-auto btn btn-link">Ver todos los socios</a>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<?php include 'footer.php'; ?>