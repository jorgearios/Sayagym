<?php 
include 'config.php';
include 'header.php'; 
?>

<div class="page-wrapper">
    <div class="container-xl mt-4">
        <div class="row align-items-center mb-4">
            <div class="col">
                <h2 class="page-title">Gestión de Socios</h2>
            </div>
            <div class="col-auto">
                <a href="nuevo_socio.php" class="btn btn-primary">
                    <i class="ti ti-plus me-2"></i> Nuevo Socio
                </a>
            </div>
        </div>

        <div class="card">
            <div class="table-responsive">
                <table class="table card-table table-vcenter">
                    <thead>
                        <tr>
                            <th>Socio / Contacto</th> <th>Plan</th>
                            <th>Entrenador</th> <th>Vencimiento</th>
                            <th class="w-1">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // LEFT JOIN para el entrenador por si no tiene asignado
                        $sql = "SELECT s.*, m.nombre as plan, e.nombre as nombre_profe 
                                FROM socios s 
                                JOIN membresias m ON s.id_membresia = m.id_membresia 
                                LEFT JOIN entrenadores e ON s.id_entrenador = e.id_entrenador
                                ORDER BY s.id_socio DESC";
                        
                        $res = $conexion->query($sql);
                        
                        while($row = $res->fetch_assoc()):
                            $vence = strtotime($row['fecha_vencimiento']);
                            $hoy = strtotime(date('Y-m-d'));
                            $status_color = ($vence < $hoy) ? 'red' : 'green';
                        ?>
                        <tr>
                            <td>
                                <div class="font-weight-medium text-dark">
                                    <?php echo $row['nombre']." ".$row['apellido']; ?>
                                </div>
                                <div class="text-muted small">
                                    <?php echo $row['telefono']; ?> 
                                    <?php if($row['correo']) echo " · " . $row['correo']; ?>
                                </div>
                            </td>
                            
                            <td><span class="badge bg-blue-lt"><?php echo $row['plan']; ?></span></td>
                            
                            <td class="text-muted small">
                                <i class="ti ti-barbell me-1"></i>
                                <?php echo $row['nombre_profe'] ?: 'Sin asignar'; ?>
                            </td>

                            <td>
                                <span class="text-<?php echo $status_color; ?> font-weight-bold">
                                    <?php echo date('d/m/Y', $vence); ?>
                                </span>
                            </td>
                            
                            <td>
                                <div class="btn-list flex-nowrap">
                                    <a href="editar_socio.php?id=<?php echo $row['id_socio']; ?>" class="btn btn-white btn-icon" title="Editar">
                                        <i class="ti ti-edit text-blue"></i>
                                    </a>
                                    <a href="eliminar_socio.php?id=<?php echo $row['id_socio']; ?>" 
                                       class="btn btn-white btn-icon" 
                                       title="Eliminar" 
                                       onclick="return confirm('¿Estás segura de eliminar a este socio?');">
                                         <i class="ti ti-trash text-red"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>